import { useState, useEffect } from "react";
import axios from "axios";
import { colors, spacing, typography, borderRadius, shadows } from "../styles/theme";
import Footer from "../components/Footer";

function AlumniDirectory() {
  const [profiles, setProfiles] = useState([]);
  const [filters, setFilters] = useState({ department: "", batchYear: "", company: "" });
  const [loading, setLoading] = useState(false);

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.department) params.append("department", filters.department);
      if (filters.batchYear) params.append("batchYear", filters.batchYear);
      if (filters.company) params.append("company", filters.company);

      const res = await axios.get(`http://localhost:5000/api/alumni/profiles?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProfiles(res.data);
    } catch (err) {
      console.error("Error fetching profiles:", err);
    } finally {
      setLoading(false);
    }
  };

  const containerStyles = { maxWidth: "1400px", margin: "0 auto", padding: `${spacing[8]} ${spacing[6]}` };

  return (
    <div style={{ background: `linear-gradient(135deg, ${colors.primary[50]} 0%, ${colors.secondary[50]} 100%)`, minHeight: "100vh" }}>
      <div style={containerStyles}>
        <h1 style={{ color: colors.primary.main, marginBottom: spacing[2] }}>Alumni Directory 👥</h1>
        <p style={{ color: colors.text.secondary, marginBottom: spacing[8] }}>
          Connect with CAHCET alumni from across batches and departments
        </p>

        {/* Filters */}
        <div style={{ background: colors.background.paper, padding: spacing[6], borderRadius: borderRadius.lg, marginBottom: spacing[8], boxShadow: shadows.md }}>
          <h3 style={{ margin: `0 0 ${spacing[4]} 0`, color: colors.primary.main }}>Search & Filter</h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: spacing[4] }}>
            <div>
              <label style={{ display: "block", marginBottom: spacing[2], fontWeight: 600 }}>Department</label>
              <select
                value={filters.department}
                onChange={(e) => setFilters({ ...filters, department: e.target.value })}
                style={{ width: "100%", padding: spacing[2], borderRadius: borderRadius.md, border: `1px solid ${colors.border}` }}
              >
                <option value="">All Departments</option>
                <option value="CSE">Computer Science</option>
                <option value="ECE">Electronics</option>
                <option value="ME">Mechanical</option>
                <option value="CE">Civil</option>
              </select>
            </div>
            <div>
              <label style={{ display: "block", marginBottom: spacing[2], fontWeight: 600 }}>Batch Year</label>
              <input
                type="number"
                placeholder="e.g., 2020"
                value={filters.batchYear}
                onChange={(e) => setFilters({ ...filters, batchYear: e.target.value })}
                style={{ width: "100%", padding: spacing[2], borderRadius: borderRadius.md, border: `1px solid ${colors.border}` }}
              />
            </div>
            <div>
              <label style={{ display: "block", marginBottom: spacing[2], fontWeight: 600 }}>Company</label>
              <input
                type="text"
                placeholder="Company name"
                value={filters.company}
                onChange={(e) => setFilters({ ...filters, company: e.target.value })}
                style={{ width: "100%", padding: spacing[2], borderRadius: borderRadius.md, border: `1px solid ${colors.border}` }}
              />
            </div>
          </div>
          <div style={{ display: "flex", gap: spacing[4], marginTop: spacing[4] }}>
            <button
              onClick={fetchProfiles}
              style={{ padding: `${spacing[2]} ${spacing[6]}`, background: colors.gradients.primary, color: "white", border: "none", borderRadius: borderRadius.md, cursor: "pointer", fontWeight: 600 }}
            >
              Search
            </button>
            <button
              onClick={() => { setFilters({ department: "", batchYear: "", company: "" }); fetchProfiles(); }}
              style={{ padding: `${spacing[2]} ${spacing[6]}`, background: "transparent", color: colors.primary.main, border: `1px solid ${colors.primary.main}`, borderRadius: borderRadius.md, cursor: "pointer", fontWeight: 600 }}
            >
              Clear
            </button>
          </div>
        </div>

        {/* Results */}
        {loading ? (
          <p>Loading profiles...</p>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: spacing[6] }}>
            {profiles.map((profile) => (
              <div
                key={profile._id}
                style={{
                  background: colors.background.paper,
                  borderRadius: borderRadius.lg,
                  padding: spacing[6],
                  boxShadow: shadows.md,
                  transition: "all 0.3s ease",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "translateY(-8px)";
                  e.currentTarget.style.boxShadow = shadows.lg;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = shadows.md;
                }}
              >
                <div style={{ fontSize: "40px", marginBottom: spacing[3] }}>👤</div>
                <h3 style={{ margin: `0 0 ${spacing[2]} 0`, color: colors.primary.main }}>{profile.name}</h3>
                <p style={{ margin: 0, color: colors.text.secondary, fontSize: typography.fontSize.sm }}>{profile.department}</p>
                <p style={{ margin: 0, color: colors.text.secondary, fontSize: typography.fontSize.sm }}>Batch: {profile.batchYear}</p>
                {profile.currentCompany && <p style={{ margin: `${spacing[2]} 0 0 0`, color: colors.secondary.main, fontWeight: 600 }}>💼 {profile.currentCompany}</p>}
              </div>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}

export default AlumniDirectory;
