import { useState, useEffect } from "react";
import { jwtDecode } from "jwt-decode";
import axios from "axios";
import { colors, spacing, typography, borderRadius, shadows } from "../styles/theme";
import Button from "../components/Button";
import Footer from "../components/Footer";

function AlumniProfile() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const token = localStorage.getItem("token");
  const decoded = token ? jwtDecode(token) : {};

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/alumni/profile", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProfile(res.data);
      setFormData(res.data);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      console.error(err);
    }
  };

  const handleUpdate = async () => {
    try {
      await axios.put("http://localhost:5000/api/alumni/profile", formData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProfile(formData);
      setIsEditing(false);
      alert("Profile updated successfully!");
    } catch (err) {
      alert("Failed to update profile");
    }
  };

  const containerStyles = { maxWidth: "1200px", margin: "0 auto", padding: `${spacing[8]} ${spacing[6]}` };

  return (
    <div style={{ background: `linear-gradient(135deg, ${colors.primary[50]} 0%, ${colors.secondary[50]} 100%)`, minHeight: "100vh" }}>
      <div style={containerStyles}>
        {loading ? (
          <p>Loading profile...</p>
        ) : (
          <>
            <div style={{ background: colors.gradients.primary, color: "white", padding: spacing[8], borderRadius: borderRadius.xl, marginBottom: spacing[12] }}>
              <h1 style={{ margin: 0, fontSize: typography.fontSize['3xl'] }}>👤 My Profile</h1>
            </div>

            <div style={{ background: colors.background.paper, borderRadius: borderRadius.xl, padding: spacing[8], boxShadow: shadows.lg }}>
              {!isEditing ? (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: spacing[6], marginBottom: spacing[6] }}>
                    <div>
                      <p style={{ color: colors.text.secondary, margin: 0, marginBottom: spacing[1] }}>Name</p>
                      <p style={{ color: colors.text.primary, margin: 0, fontSize: typography.fontSize.lg, fontWeight: 600 }}>{profile?.name}</p>
                    </div>
                    <div>
                      <p style={{ color: colors.text.secondary, margin: 0, marginBottom: spacing[1] }}>Email</p>
                      <p style={{ color: colors.text.primary, margin: 0, fontSize: typography.fontSize.lg, fontWeight: 600 }}>{profile?.email}</p>
                    </div>
                    <div>
                      <p style={{ color: colors.text.secondary, margin: 0, marginBottom: spacing[1] }}>Department</p>
                      <p style={{ color: colors.text.primary, margin: 0, fontSize: typography.fontSize.lg, fontWeight: 600 }}>{profile?.department}</p>
                    </div>
                    <div>
                      <p style={{ color: colors.text.secondary, margin: 0, marginBottom: spacing[1] }}>Batch Year</p>
                      <p style={{color: colors.text.primary, margin: 0, fontSize: typography.fontSize.lg, fontWeight: 600 }}>{profile?.batchYear}</p>
                    </div>
                    <div>
                      <p style={{ color: colors.text.secondary, margin: 0, marginBottom: spacing[1] }}>Current Company</p>
                      <p style={{ color: colors.text.primary, margin: 0, fontSize: typography.fontSize.lg, fontWeight: 600 }}>{profile?.currentCompany || "N/A"}</p>
                    </div>
                  </div>
                  <Button variant="primary" onClick={() => setIsEditing(true)}>
                    Edit Profile
                  </Button>
                </>
              ) : (
                <>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: spacing[4], marginBottom: spacing[6] }}>
                    <div>
                      <label style={{ display: "block", marginBottom: spacing[2], fontWeight: 600 }}>Name</label>
                      <input
                        type="text"
                        value={formData.name || ""}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        style={{ width: "100%", padding: spacing[2], borderRadius: borderRadius.md, border: `1px solid ${colors.border}` }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", marginBottom: spacing[2], fontWeight: 600 }}>Department</label>
                      <input
                        type="text"
                        value={formData.department || ""}
                        onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                        style={{ width: "100%", padding: spacing[2], borderRadius: borderRadius.md, border: `1px solid ${colors.border}` }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", marginBottom: spacing[2], fontWeight: 600 }}>Batch Year</label>
                      <input
                        type="number"
                        value={formData.batchYear || ""}
                        onChange={(e) => setFormData({ ...formData, batchYear: e.target.value })}
                        style={{ width: "100%", padding: spacing[2], borderRadius: borderRadius.md, border: `1px solid ${colors.border}` }}
                      />
                    </div>
                    <div>
                      <label style={{ display: "block", marginBottom: spacing[2], fontWeight: 600 }}>Current Company</label>
                      <input
                        type="text"
                        value={formData.currentCompany || ""}
                        onChange={(e) => setFormData({ ...formData, currentCompany: e.target.value })}
                        style={{ width: "100%", padding: spacing[2], borderRadius: borderRadius.md, border: `1px solid ${colors.border}` }}
                      />
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: spacing[4] }}>
                    <Button variant="primary" onClick={handleUpdate}>
                      Save Changes
                    </Button>
                    <Button variant="outline" onClick={() => setIsEditing(false)}>
                      Cancel
                    </Button>
                  </div>
                </>
              )}
            </div>
          </>
        )}
      </div>
      <Footer />
    </div>
  );
}

export default AlumniProfile;
